import numpy as np
import pandas as pd

# membuat vektor
A = np.array([
    [1,2,3],
    [4,5,6],
    [7,8,9]]) 

B = np.array([
 [1,2,3],
 [4,5,6],
 [7,8,9]
])

c = np.add(A,B)
print("Jumlah dari A + B adalah",c)

c = np.multiply(A,B)
print("Perkalian dari A * B adalah",c)

data = pd.read_csv('harga_rumah.csv') 
print (data.head())
print(df.iloc[4])

X = df.drop(['harga'],axis=1)
print(X.head())
