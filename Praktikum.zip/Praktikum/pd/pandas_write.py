import pandas as pd

# menulis file
df = pd.DataFrame({
 'nama': ['Budi', 'Siti'],
 'jenis': ['Laki-laki', 'Perempuan'],
 'usia': [22, 21]
})
df.to_csv('fileku.csv',index=False)


