import pandas as pd

data = pd.read_csv('harga_rumah.csv') 
print (data.head())
df = pd.DataFrame(data)

print(df.iloc[:,4])

X = df.drop(['harga'],axis=1)
print(X.head())