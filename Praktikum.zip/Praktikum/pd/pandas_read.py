import pandas as pd
# membaca file
data = pd.read_csv('harga_rumah.csv') # membaca file csv
print (data.head()) # .head() berfungsi untuk menampilkan top 5 data

# membaca salah satu kolom berdasarkan nama kolom
df = pd.DataFrame(data)
#print(df.jml_lantai)
#print(df['jml_lantai'])

# membaca baris pertama saja
print(df.iloc[0])

# membaca semua baris pada kolom tertentu berdasarkan index
print(df.iloc[:,1]) # iloc[:,1] -> tanda : artinya semua baris, 1 artinya index kolom ke-1

# membuat kolom tertentu untuk mengambil sisa kolom yang lain
# axis = 1 artinya hanya mengambil kolom
# bentuk dari X adalah matriks 2D
X = df.drop(['harga'],axis=1)
print(X.head())

# mengubah nama kolom
df = df.rename(columns={'jml_lantai':'lantai'})
print(df.head())
