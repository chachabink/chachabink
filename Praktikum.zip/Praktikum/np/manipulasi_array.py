import numpy as np

# mengakses elemen dari vektor/matriks
A = np.array([1,2,3])
a = A[2] # angka 2 adalah indeks. Indeks dimulai dari 0
print("Elemen ke-2 dari vektor A adalah",a)
B = np.array([
 [1,2,1],
 [2,1,3],
 [3,2,2]
])

# mengubah matriks 2 dimensi ke vektor
vB = B.ravel()
print(vB)
D = np.array([
 [1,2,1],
 [2,1,3],
 [3,2,2],
 [4,5,6]
])
# mengubah bentuk array
vC = D.reshape(6, 2) # mengubah bentuk array dari 3x4 menjadi 6x2
print(vC)
# mengubah bentuk array ke vektor 1D
vC = D.reshape(1,-1) # sama dengan ravel()
print(vC)
